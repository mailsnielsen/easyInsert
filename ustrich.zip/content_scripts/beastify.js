(function () {
    /**
     * Check and set a global guard variable.
     * If this content script is injected into the same page again,
     * it will do nothing next time.
     */
    if (window.hasRun) {
        return;
    }
    window.hasRun = true;

    /**
     * Given a URL to a beast image, remove all existing beasts, then
     * create and style an IMG node pointing to
     * that image, then insert the node into the document.
     */
    function insert(data) {
        var object = serializeIt(data)

        document.getElementById('projectadmin_project_name').value = object.projectname;
        document.getElementById('projectadmin_project_number').value = object.projectnumber;
        document.getElementById('projectadmin_project_category').value = 14;
        document.getElementById('projectadmin_location').value = object.buildingplace;
        document.getElementById('projectadmin_start_date').value = object.start_date;
        document.getElementById('projectadmin_work_package_preset').value = 7;
        document.getElementById('projectadmin_client__search').value = object.customer;
        document.getElementById('projectadmin_project_phase').value = 2;
        document.getElementById('projectadmin_f_2').value = object.builder;
        document.getElementById('projectadmin_f_3').value = "Mappe";

        document.getElementById("projectadmin_client__search").click();

    }

    function serializeIt(data) {
        var number = data[0].split('/');

        var object = {
            projectname: data[1] + ', ' + data[7] + ' _' + data[6],
            projectnumber: 'P' + pad(number[0], 3) + '-' + number[1],
            buildingplace: data[7],
            start_date: data[8],
            builder: data[1] + ', ' + data[2],
            customer: searchFor(data[3]),
        }

        return object;
    }


    /** here are the specific functions */

    function searchFor(client) {
        switch (client) {
            case 'SL-FL':
                return 'Kreis SL-FL';
                break;

            case 'FL':
                return 'Stadt Flensburg';
                break;

            case 'SL':
                return 'Stadt Schleswig';
                break;

            case 'NF':
                return 'Kreis NF';
                break;

            case 'GM.SH':
                return 'Gebäudemanagement';
                break;

            default:
                break;
        }
    }


    function pad(n, width, z) {
        z = z || '0';
        n = n + '';
        return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
    }

    /**
     * Listen for messages from the background script.
     * Call "beastify()" or "reset()".
    */
    browser.runtime.onMessage.addListener((message) => {
        if (message.command === "complete") {
            insert(message.data);
        }
    });

})();