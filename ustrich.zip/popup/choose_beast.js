
/**
 * Listen for clicks on the buttons, and send the appropriate message to
 * the content script in the page.
 */
function listenForClicks() {
    document.addEventListener("click", (e) => {
        if (e.target.id == 'submit') {
            browser.tabs.query({ active: true, currentWindow: true })
                .then(complete)
        };

        function complete(tabs) {
            var str = document.getElementById("input").value
            var explode = str.split('\t');

            console.log(explode)

            browser.tabs.sendMessage(tabs[0].id, {
                command: "complete",
                data: explode
            });
        }


    });
}
/**
 * When the popup loads, inject a content script into the active tab,
 * and add a click handler.
 * If we couldn't inject the script, handle the error.
 */
browser.tabs.executeScript({ file: "/content_scripts/beastify.js" })
    .then(listenForClicks)
    .catch();